import { useEffect, useState } from "react";

const OTCDataReader = ({ onData }) => {
  const [otcData, setOtcData] = useState([]);

  useEffect(() => {
    const interval = setInterval(() => {
      try {
        const rows = document.querySelectorAll(".otc-asset-row");
        const data = Array.from(rows).map(row => ({
          asset: row.querySelector(".asset-name")?.innerText || "OTC-Unknown",
          bid: parseFloat(row.querySelector(".bid-price")?.innerText || 0),
          ask: parseFloat(row.querySelector(".ask-price")?.innerText || 0),
          last: parseFloat(row.querySelector(".last-price")?.innerText || 0),
          time: new Date().toISOString(),
        }));
        setOtcData(data);
        onData && onData(data);
      } catch (err) {
        console.error("OTC read error:", err);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [onData]);

  return null;
};

export default OTCDataReader;
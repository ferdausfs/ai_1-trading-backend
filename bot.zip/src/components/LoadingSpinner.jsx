import React from "react";

const LoadingSpinner = () => <div>Loading...</div>;

export default LoadingSpinner;
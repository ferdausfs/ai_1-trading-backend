import React, { useState } from "react";

const Settings = () => {
  const [apiKeys, setApiKeys] = useState({
    cerebras: "csk-h6r48pth4wft2t34c6wj6kyd6k8pxwmtvkehxr259r4j2tcf",
    forex: "MAMTVHN6E67YD3A5",
    crypto: "CG-VS9XbpxNffYAXJCp8PDpKMKj"
  });

  const handleChange = (e) =>
    setApiKeys({ ...apiKeys, [e.target.name]: e.target.value });

  const saveKeys = () => {
    localStorage.setItem("apiKeys", JSON.stringify(apiKeys));
    alert("API Keys saved!");
  };

  return (
    <div className="settings">
      <h3>API Keys</h3>
      <input
        name="cerebras"
        placeholder="Cerebras AI Key"
        value={apiKeys.cerebras}
        onChange={handleChange}
      />
      <input
        name="forex"
        placeholder="Forex API Key"
        value={apiKeys.forex}
        onChange={handleChange}
      />
      <input
        name="crypto"
        placeholder="Crypto API Key"
        value={apiKeys.crypto}
        onChange={handleChange}
      />
      <button onClick={saveKeys}>Save</button>
    </div>
  );
};

export default Settings;
import React, { useState } from "react";
import Home from "./pages/Home";
import Trading from "./pages/Trading";
import SettingsPage from "./pages/SettingsPage";

const App = () => {
  const [page, setPage] = useState("home");

  return (
    <div>
      <nav>
        <button onClick={() => setPage("home")}>Home</button>
        <button onClick={() => setPage("trading")}>Trading</button>
        <button onClick={() => setPage("settings")}>Settings</button>
      </nav>

      {page === "home" && <Home />}
      {page === "trading" && <Trading />}
      {page === "settings" && <SettingsPage />}
    </div>
  );
};

export default App;